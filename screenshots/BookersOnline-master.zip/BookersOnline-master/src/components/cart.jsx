import React from 'react';

function Cart(){
    return(
        <p>Cart of bookersOnline</p>
    )
}

export default Cart;